CS 61 Problem Set 2
===================

This is bomb #58.

It belongs to junjang17 (junjang@college.harvard.edu).
